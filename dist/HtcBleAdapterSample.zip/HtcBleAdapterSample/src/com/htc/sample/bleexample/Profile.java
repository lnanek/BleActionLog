package com.htc.sample.bleexample;

public enum Profile {
	
	FIND_ME,
	HEART_RATE

}
